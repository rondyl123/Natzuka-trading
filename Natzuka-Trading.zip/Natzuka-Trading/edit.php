
<?php
//require "config/constants.php";

session_start();
if(!isset($_SESSION["uid"])){
	header("location:index.php");
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Natzuka Trading</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<script src="js/jquery2.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="main.js"></script>
		<style>
			table tr td {padding:10px;}
		</style>
	</head>
<body>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<a href="#" class="navbar-brand">Online Bike Store</a>
			</div>
			<ul class="nav navbar-nav">
				<li><a href="index.php"><span class="glyphicon glyphicon-home"></span>Home</a></li>
				<li><a href="index.php"><span class="glyphicon glyphicon-modal-window"></span>Product</a></li>
			</ul>
		</div>
	</div>
	<p><br/></p>
	<p><br/></p>
	<p><br/></p>
	
	<div class="container-fluid">
	
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="panel panel-default">
					<div class="panel-heading"></div>
					<div class="panel-body">
						<h1>Account Settings</h1>
						<hr/>	
                       <?php
				include('db.php');
				$id=$_GET['id'];
				$sql=mysqli_query($con,"select * from `user_info` where user_id='$id'");
				$row=mysqli_fetch_array($sql);

?>
					<form method="POST" action="update.php?id=<?php echo $id; ?>">
						<tr><td><label>First Name: </label><input type="text" value="<?php echo $row['first_name']; ?>" name="first_name"></b></td></tr><br>
						<tr><td><label>Last Name: </label><input type="text" value="<?php echo $row['last_name']; ?>" name="last_name"></b></td></tr><br>
						<tr><td><label>Email: </label><input type="text" value="<?php echo $row['email']; ?>" name="email"></b></td></tr><br>
						<tr><td><label>Mobile #: </label><input type="text" value="<?php echo $row['mobile']; ?>" name="mobile"></b></td></tr><br>
						<tr><td><label>Address: </label><input type="text" value="<?php echo $row['address1']; ?>" name="address1"></b></td></tr><br>
						<tr><td><label>Address: </label><input type="text" value="<?php echo $row['address2']; ?>" name="address2"></b></td></tr><br>
						<input type="submit" name="Update">
						<a href="accountsetting.php">Back</a>
					</form>
						
					</div>
					<div class="panel-footer"></div>
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>
</body>
</html>
	
	
