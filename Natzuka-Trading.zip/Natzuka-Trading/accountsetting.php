<?php
//require "config/constants.php";

session_start();
if(!isset($_SESSION["uid"])){
	header("location:index.php");
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Natzuka Trading</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<script src="js/jquery2.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="main.js"></script>
		<style>
			table tr td {padding:10px;}
		</style>
	</head>
<body>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<a href="#" class="navbar-brand">Online Bike Store</a>
			</div>
			<ul class="nav navbar-nav">
				<li><a href="index.php"><span class="glyphicon glyphicon-home"></span>Home</a></li>
				<li><a href="index.php"><span class="glyphicon glyphicon-modal-window"></span>Product</a></li>
			</ul>
		</div>
	</div>
	<p><br/></p>
	<p><br/></p>
	<p><br/></p>

    <div class="container-fluid">
	
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="panel panel-default">
					<div class="panel-heading"></div>
					<div class="panel-body">
						<h1>Account Settings</h1>
						<hr/>	
                        <?php
							include("db.php");
							$user_id = $_SESSION["uid"];
                            
				    $sql=mysqli_query($con,"select * from `user_info` where user_id='$user_id'");
					if (mysqli_num_rows($sql) > 0) {
					while($row=mysqli_fetch_array($sql)){
						?>
                        <div class="col-md-6">
									<table>
													<tr><td>First Name</td><td><b><?php echo $row['first_name']; ?></b> </td></tr>
                                                    <tr><td>Last Name</td><td><b><?php echo $row['last_name']; ?></b></td></tr>
													<tr><td>Email</td><td><b><?php echo $row['email']; ?></b></td></tr>
													
                                                    <tr><td>Mobile</td><td><b><?php echo $row['mobile']; ?></b></td></tr>
                                                    <tr><td>address</td><td><b><?php echo $row['address1']; ?></b></td></tr>
                                                    <tr><td>address</td><td><b><?php echo $row['address2']; ?></b></td></tr>

                                                    <tr><td> <a href="edit.php?id=<?php echo $row['user_id']; ?>">Edit</a></b></td></tr>
													<tr><td> <a href="changepass.php">Change Password</a></b></td></tr>
                                                    
												</table>
											</div>
										</div>
									<?php
						
					}
                    
				}
						?>	
                        
						
						
					</div>
					<div class="panel-footer"></div>
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>
  
   


</body>
</html>

